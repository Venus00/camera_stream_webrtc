const peer = new Peer({
    id: "oussamaFARHAT",
    config: {
        iceServers: [
            { urls: "stun:stun.relay.metered.ca:80" },
            {
                urls: "turn:a.relay.metered.ca:80",
                username: "fa35f3aab7723b88f2f72ab0",
                credential: "B/glka1X3gSXhIRO",
            },
            {
                urls: "turn:a.relay.metered.ca:80?transport=tcp",
                username: "fa35f3aab7723b88f2f72ab0",
                credential: "B/glka1X3gSXhIRO",
            },
            {
                urls: "turn:a.relay.metered.ca:443",
                username: "fa35f3aab7723b88f2f72ab0",
                credential: "B/glka1X3gSXhIRO",
            },
            {
                urls: "turn:a.relay.metered.ca:443?transport=tcp",
                username: "fa35f3aab7723b88f2f72ab0",
                credential: "B/glka1X3gSXhIRO",
            },
        ],
    }
});

let currentCall;
peer.on("open", function (id) {
    document.getElementById("uuid").innerHTML = id;
});

async function callUser() {
    const peerId = document.querySelector("input").value;
    const emptyStream = new MediaStream();
    // Do NOT get local media
    const call = peer.call(peerId, emptyStream);  // ❗️Call with no media stream
    if (!call) {
        console.error("Call failed: peer may be unavailable or ID is incorrect.");
        alert("Could not call the peer. Please check their ID or if they are online.");
        return;
    }

    call.on("stream", (stream) => {
        console.log("stream", stream);
        const remoteVideo = document.getElementById("remote-video");
        remoteVideo.srcObject = stream;
        remoteVideo.play();
    });

    call.on("error", (err) => {
        console.log(err);
    });

    call.on("close", () => {
        endCall();
    });

    currentCall = call;
}


function endCall() {
    if (!currentCall) return;
    try {
        currentCall.close();
    } catch { }
    currentCall = undefined;
}
